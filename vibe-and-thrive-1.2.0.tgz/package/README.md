# Vibe and Thrive

**Tools to help you thrive with agentic coding in the Claude CLI.**

Vibe-and-thrive is a toolkit for [Claude Code](https://docs.anthropic.com/en/docs/claude-code) that helps you ship quality code faster with AI. It includes:

- **Ralph** - Autonomous coding loop that writes, tests, and commits until done (inspired by [RALPH](https://ghuntley.com/ralph/))
- **`/vibe-check`** - Code quality audits to catch common AI-generated issues
- **`/review`** - Security-focused code review with OWASP checks
- **Pre-commit hooks** - Block secrets, localhost URLs, and security issues
- **`/styleguide`** - Generate a UI component reference from your codebase
- **`/my-dna`** - Interactive guide to adding your personal voice to CLAUDE.md

## Install

In your project:

```bash
npm install vibe-and-thrive
```

This launches an interactive setup that:
- Installs slash commands to `.claude/commands/`
- Sets up pre-commit hooks
- Initializes Ralph (`.ralph/` directory)
- Configures Chrome DevTools MCP for browser validation

## Quick Start

After install, open Claude Code:

| New here? | Ready to build? |
|-----------|-----------------|
| Run `/tour` for an interactive walkthrough that explains the workflow and sets up your preferences. | Run `/idea "your feature"` to brainstorm, then `ralph run` to build it. |

## Workflow

### Step 1: Plan with Claude

```bash
cd your-project
claude
```

In Claude:
1. `/idea "your feature"` - brainstorm and create PRD
2. Review and approve the idea file
3. Review and approve the PRD
4. Type `/exit` when PRD is ready

### Step 2: Execute with Ralph

```bash
ralph run
```

Ralph will:
- Loop through each story in `.ralph/prd.json`
- Spawn fresh Claude sessions (one per story)
- Run 6-step verification after each story
- Auto-run migrations if new migration files are detected
- Commit on success, retry on failure

**Important:** Run `ralph run` in your terminal, not inside Claude. Ralph spawns its own Claude sessions.

> **Pro tip:** Use two terminals - plan with Claude in one, run Ralph in another. This lets you monitor progress or jump back into Claude while Ralph works.

## How Ralph Works

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│             │     │             │     │             │     │             │
│   /idea     │────▶│   Approve   │────▶│ ralph run   │────▶│    Ship     │
│             │     │             │     │             │     │             │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
       │                   │                   │                   │
       ▼                   ▼                   ▼                   ▼
 docs/ideas/        .ralph/prd.json      Loop until           Push to
 feature.md         with stories         all stories          remote
                                         are done
```

### 1. `/idea` → `docs/ideas/feature.md`

Describe your feature to Claude. Together you brainstorm, explore the codebase, and write a feature doc to `docs/ideas/`. You review and approve the idea.

### 2. Approve → `.ralph/prd.json`

Claude splits your approved idea into small, testable stories and writes them to `.ralph/prd.json`. Each story has acceptance criteria, test steps, error handling requirements, and more. You review and approve the PRD.

### 3. `ralph run` → Loop until done

```
                 ┌─────────────────────────┐
                 │   Get next story from   │
                 │   prd.json (TODO)       │
                 └───────────┬─────────────┘
                             │
                             ▼
                 ┌─────────────────────────┐
                 │   Claude writes code    │
                 └───────────┬─────────────┘
                             │
                             ▼
                 ┌─────────────────────────┐
                 │   6-Step Verification   │
                 │                         │
                 │   1. Code review        │
                 │   2. Lint/build         │
                 │   3. Unit tests         │
                 │   4. E2E/API tests      │
                 │   5. Browser validation │
                 │   6. PRD test steps     │
                 └───────────┬─────────────┘
                             │
              ┌──────────────┴──────────────┐
              │                             │
              ▼                             ▼
       ┌─────────────┐               ┌─────────────┐
       │    DONE     │               │  NOT YET    │
       └──────┬──────┘               └──────┬──────┘
              │                             │
              ▼                             │
       ┌─────────────┐                      │
       │ Mark story  │                      │
       │ done in     │                      │
       │ prd.json    │                      │
       └──────┬──────┘                      │
              │                             │
              ▼                             │
       ┌─────────────┐                      │
       │ git commit  │                      │
       └──────┬──────┘                      │
              │                             │
              ▼                             │
       ┌─────────────┐    Save errors,      │
       │ Next story  │    try again         │
       └──────┬──────┘         ┌────────────┘
              │                │
              └────────────────┘
```

### 4. Ship

All stories complete. All tests passing. All commits made. Push when ready.

## Commands

### Claude Code Slash Commands

| Command | What it does |
|---------|--------------|
| `/idea "feature"` | Brainstorm and generate PRD for Ralph |
| `/tour` | Interactive walkthrough for new users |
| `/my-dna` | Set up your personal voice in CLAUDE.md |
| `/vibe-check` | Audit code quality before shipping |
| `/review` | Code review with security checks |
| `/explain` | Understand existing code line by line |
| `/styleguide` | Generate UI component reference |
| `/vibe-help` | Quick reference cheatsheet |

### Terminal Commands

| Command | What it does |
|---------|--------------|
| `ralph run` | Start autonomous loop |
| `ralph status` | Check progress |
| `ralph check` | Run verification only |
| `ralph verify US-001` | Verify specific story |
| `ralph signs` | Show learned patterns |
| `ralph sign "pattern"` | Teach Ralph a pattern |

## License

MIT - see [LICENSE](LICENSE)

---

Built by [AllThrive AI](https://allthrive.ai)
